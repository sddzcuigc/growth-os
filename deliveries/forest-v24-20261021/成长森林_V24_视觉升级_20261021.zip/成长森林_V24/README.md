# 成长森林 V24：视觉升级

本轮实现日期：2026-10-21。产品目标仍是把大能力拆成具体小技能，通过学习、复习和真实项目应用、检验，让孩子看见自己做成的事情。

## 本轮变化

原创森林主视觉、统一中文排版与线性图标、清楚的技能节点、项目入口、技能操作卡和离线技能图谱。移除固定假连续天数与徽章装饰；项目结果显示实际记录，加入技能计划仍不发奖励或认定掌握。

保留 V23 的 72 项技能、11 条路线、8 个项目，以及统一账号、自动同步、离线补传、冲突保留、账号隔离和事件去重。界面版本升级为 V24，数据协议继续兼容 23，没有改动服务端数据结构。

## 直接查看

- [离线技能树总览](docs/技能树总览.html)：无需服务器或登录，点击路线会展开对应技能卡。
- [电脑界面截图](evidence/v24-desktop-home.png)、[手机界面截图](evidence/v24-phone-home.png)。
- [视觉规范、插画提示词与素材说明](design/视觉规范与资产.md)。
- [技能路线与阶段目标](docs/路线设计与阶段目标.md)。

## 本地运行与验证

需要 Node 22.13 以上。云端推荐 Node 24。

```powershell
npm ci
npm run dev:local
```

仅用于本机演示的身份必须显式启用，且仅监听回环地址；线上强制禁用该身份。正式登录运行 `npm run dev`，并配置正确的账号授权域与持久化数据库。

```powershell
npm run build:overview
npm run validate
npm run test:sync
npm run test:atomic
npm run test:roadmap
node tests/visual-content.mjs
npm run test:multi-device
node tests/overview.mjs
npm run build:web
```

浏览器测试使用本机已安装的 Microsoft Edge。证据见 evidence 里的 JSON 与真实截图；手机和平板为浏览器模拟。没有将测试身份当作生产 Firebase 账号验收。

## 当前边界

生产网站未发布，草稿 PR 和 Git 分支继续供审阅。尚未获得生产发布、主分支合并或受保护预览临时访问链接的额外授权。

原生安装包、真实手机/平板、生产账号同步、完整无障碍认证和真实儿童教学效果尚未验收。旧版预设人物、经验和果实等级仍是原项目示例与按次数呈现的游戏反馈，不能作为独立能力测评。

工程包不含 node_modules、用户数据库或服务端密钥。图标许可与原创插画原图、提示词随包保留。
